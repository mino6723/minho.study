package board.free.dao;

import java.util.List;

import board.free.domain.FreeVO;

public interface FreeDao {
	public abstract List<FreeVO> list();
	
	public abstract int delete(FreeVO freeVO);
	
	public abstract  int deleteAll();
	
	public abstract  int update(FreeVO freeVO);
	
	public abstract void insert(FreeVO freeVO);
	
	public abstract FreeVO select(int num);
	
	public abstract int updateReadCount(int num);
	
	public abstract List<FreeVO> listSearch(String searchOption, String keyword);
	
	public abstract int countArticle(String searchOption, String keyword);
	
	public abstract List<FreeVO> listAll(int start, int end, String searchOption, String keyword);
}