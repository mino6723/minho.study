package board.free.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

import board.free.domain.FreeVO;

@Repository
public class FreeDaoMybatis implements FreeDao{
	private SqlSessionTemplate sst;
	
	public FreeDaoMybatis(SqlSessionTemplate sst) {
		this.sst = sst;
	}
	
	public void setSqlMapClient(SqlSessionTemplate sst) {
		this.sst = sst;
	}
	
	@Override
	public List<FreeVO> list() {
		return sst.selectList("list");
	}
	
	@Override
	public int delete(FreeVO freeVO) {
		return sst.delete("delete", freeVO);
	}
	
	@Override
	public int deleteAll() {
		return sst.delete("deleteAll");
	}
	
	@Override
	public int update(FreeVO freeVO) {
		return sst.update("update", freeVO);
	}
	
	@Override
	public void insert(FreeVO freeVO) {
		sst.insert("insert", freeVO);
	}
	
	@Override
	public FreeVO select(int num) {
		FreeVO vo = (FreeVO)sst.selectOne("select", num);
		return vo;
	}
	
	@Override
	public int updateReadCount(int num) {
		return sst.update("updateCount", num);
	}
}
