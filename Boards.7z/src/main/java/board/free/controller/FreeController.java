package board.free.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import board.free.domain.FreeVO;
import board.free.service.FreeService;

@Controller
@SessionAttributes("FreeVO")
public class FreeController {
	private FreeService freeService;
	
	public void setFreeService(FreeService freeService) {
		this.freeService = freeService;
	}
	
	@RequestMapping(value="/free/list")
	public String list(Model model) {
		model.addAttribute("freeList", freeService.list());
		return "/free/list";
	}
	
	@RequestMapping(value="/free/read/{num}")
	public String read(Model model, @PathVariable int num) {
		model.addAttribute("freeVO", freeService.read(num));
		return "/free/read";
	}
	
	@RequestMapping(value="/free/write", method=RequestMethod.GET)
	public String write(Model model) {
		model.addAttribute("freeVO", new FreeVO());
		return "/free/write";
	}
	
	@RequestMapping(value="/free/write", method=RequestMethod.POST)
	public String write(@Valid FreeVO freeVO, BindingResult bindingResult) {
		if(bindingResult.hasErrors()) {
			return "/free/write";
		}
		freeService.write(freeVO);
		return "redirect:/free/list";
	}
	
	@RequestMapping(value="/free/edit/{num}", method=RequestMethod.GET)
	public String edit(@PathVariable int num, Model model) {
		FreeVO freeVO = freeService.read(num);
		model.addAttribute("freeVO", freeVO);
		return "/free/edit";
	}
	
	@RequestMapping(value="/free/edit/{num}", method=RequestMethod.POST)
	public String edit(@Valid @ModelAttribute FreeVO freeVO,
			BindingResult result, String writer,
			SessionStatus sessionStatus, Model model) {
		if(result.hasErrors()){
			return "/free/edit";
		}else {
			if(freeVO.getWriter() == writer) {
				freeService.edit(freeVO);
				sessionStatus.setComplete();
				return "redirect:/free/list";
			}
			model.addAttribute("msg", "작성자가 다릅니다.");
			return "/free/edit";
		}
	}
	
	@RequestMapping(value="/free/delete/{num}", method=RequestMethod.GET)
	public String delete(@PathVariable int num, Model model) {
		model.addAttribute("num", num);
		return "/free/delete";
	}
	
	@RequestMapping(value="/free/delete", method=RequestMethod.POST)
	public String delete(int num, String write, Model model) {
		int rowCount;
		FreeVO freeVO = new FreeVO();
		freeVO.setNum(num);
		freeVO.setWriter(write);
		
		rowCount = freeService.delete(freeVO);
		
		if(rowCount == 0) {
			model.addAttribute("num", num);
			model.addAttribute("msg", "작성자가 일치하지않습니다.");
			return "/free/delete";
		}else {
			return "redirect:/free/list";
		}
	}
}
