package board.free.service;

import java.util.List;

import board.free.domain.FreeVO;

public interface FreeService {
	public abstract List<FreeVO> list();
	
	public abstract int delete(FreeVO freeVO);
	
	public abstract int edit(FreeVO freeVO);
	
	public abstract void write(FreeVO freeVO);
	
	public abstract FreeVO read(int num);
}
