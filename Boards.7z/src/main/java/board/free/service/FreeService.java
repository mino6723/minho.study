package board.free.service;

import java.util.List;

import board.free.domain.FreeVO;

public interface FreeService {
	public abstract List<FreeVO> list();
	
	public abstract int delete(FreeVO freeVO);
	
	public abstract int edit(FreeVO freeVO);
	
	public abstract void write(FreeVO freeVO);
	
	public abstract FreeVO read(int num);
	
	public abstract List<FreeVO> listSearch(String searchOption, String keyword);
	
	public abstract int countArticle(String searchOption, String keyword);
	
	public abstract List<FreeVO> listAll(int start, int end, String searchOption, String keyword);
}
