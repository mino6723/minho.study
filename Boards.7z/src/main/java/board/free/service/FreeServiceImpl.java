package board.free.service;

import java.util.List;

import org.springframework.stereotype.Service;

import board.free.dao.FreeDao;
import board.free.domain.FreeVO;

@Service
public class FreeServiceImpl implements FreeService{
	private FreeDao freeDao;
	
	public FreeDao getFreeDao() {
		return freeDao;
	}
	
	public void setFreeDao(FreeDao freeDao) {
		this.freeDao = freeDao;
	}
	
	@Override
	public List<FreeVO> list() {
		return freeDao.list();
	}
	
	@Override
	public int delete(FreeVO freeVO) {
		return freeDao.delete(freeVO);
	}
	
	@Override
	public int edit(FreeVO freeVO) {
		return freeDao.update(freeVO);
	}
	
	@Override
	public void write(FreeVO freeVO) {
		freeDao.insert(freeVO);
	}
	
	@Override
	public FreeVO read(int num) {
		freeDao.updateReadCount(num);
		return freeDao.select(num);
	}
}